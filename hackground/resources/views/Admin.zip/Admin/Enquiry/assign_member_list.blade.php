@extends('Admin.layouts.app')

@section('content')

<div class="body-page-loader d-none">
    <div class="loader">
        <div class="line-scale-pulse-out">
            <div class="bg-warning"></div>
            <div class="bg-warning"></div>
            <div class="bg-warning"></div>
            <div class="bg-warning"></div>
            <div class="bg-warning"></div>
        </div>
    </div>
</div>

<div class="app-main__inner">

    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-notebook icon-gradient bg-mixed-hopes"></i>
                </div>
                <div>{{ $main_title }}
                    <div class="page-title-subheading">{{ $second_title }} &gt; {{ $title }}</div>
                </div>
            </div>
            <div class="page-title-actions">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}"> Home</a></li>
                    <li class="breadcrumb-item active">{{ $main_title }}</li>
                </ol>
            </div>
        </div>
    </div>
    <div id="successMessageContainer"></div>
    <style>
        .advance-search-panel {
            background-color: #fff;
            box-shadow: 0 1px 3px rgb(0 0 0 / 10%);
            padding: 1rem;
            margin-top: 1rem;
        }

        /* Modern Lead Management UI updates */
        .custom-card {
            background: #ffffff;
            border: 1px solid #eef2f6;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02);
            margin-bottom: 1.5rem;
            overflow: hidden;
        }
        .custom-card-header {
            padding: 1.25rem 1.5rem;
            background: #ffffff;
            border-bottom: 1px solid #f1f5f9;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .custom-card-header h4 {
            font-size: 1.15rem;
            font-weight: 600;
            color: #1e293b;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        .custom-card-header h4 i {
            font-size: 1.25rem;
            color: #3b82f6;
            background: #eff6ff;
            padding: 0.5rem;
            border-radius: 8px;
        }
        .custom-card-body {
            padding: 1.5rem;
        }
        
        /* Lead Details Info Grid */
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem 2.5rem;
        }
        @media (max-width: 768px) {
            .info-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
        }
        .info-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding-bottom: 0.85rem;
            border-bottom: 1px dotted #e2e8f0;
        }
        .info-item:last-child {
            border-bottom: none;
        }
        .info-icon-container {
            width: 38px;
            height: 38px;
            background-color: #eff6ff;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        .info-icon-container i {
            color: #3b82f6;
            font-size: 1rem;
        }
        .info-content {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.92rem;
            color: #334155;
            flex-grow: 1;
        }
        .info-label {
            font-weight: 600;
            color: #1e293b;
            width: 140px;
            flex-shrink: 0;
        }
        .info-colon {
            color: #64748b;
            margin-right: 0.5rem;
            flex-shrink: 0;
        }
        .info-value {
            color: #475569;
            word-break: break-word;
        }
        
        /* Calendar Badge */
        .calendar-badge {
            background: #eff6ff;
            border: 1px solid #dbeafe;
            border-radius: 8px;
            padding: 0.4rem 0.85rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        .calendar-badge-icon {
            width: 32px;
            height: 32px;
            background: #3b82f6;
            color: #ffffff;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
        }
        .calendar-badge-text {
            display: flex;
            flex-direction: column;
            line-height: 1.25;
        }
        .calendar-badge-label {
            font-size: 0.72rem;
            font-weight: 500;
            color: #64748b;
        }
        .calendar-badge-value {
            font-size: 0.88rem;
            font-weight: 700;
            color: #1e293b;
        }

        /* Navigation Tabs */
        .custom-tabs-container {
            margin-bottom: 1.5rem;
        }
        .custom-tabs {
            display: flex;
            gap: 0.75rem;
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .custom-tab-link {
            display: inline-block;
            padding: 0.5rem 1.25rem;
            border-radius: 6px;
            font-size: 0.9rem;
            font-weight: 500;
            text-decoration: none !important;
            transition: all 0.2s ease;
        }
        .custom-tab-link.active {
            background-color: #0d6efd;
            color: #ffffff !important;
            box-shadow: 0 4px 10px rgba(13, 110, 253, 0.2);
            border: 1px solid #0d6efd;
        }
        .custom-tab-link:not(.active) {
            background-color: #ffffff;
            color: #475569 !important;
            border: 1px solid #e2e8f0;
        }
        .custom-tab-link:not(.active):hover {
            background-color: #f8fafc;
            border-color: #cbd5e1;
        }

        /* Modern Table styling */
        .custom-table {
            width: 100%;
            border-collapse: collapse;
        }
        .custom-table th {
            background-color: #f8fafc;
            color: #475569;
            font-weight: 600;
            font-size: 0.85rem;
            padding: 1rem;
            text-transform: capitalize;
            border-bottom: 1px solid #e2e8f0;
        }
        .custom-table td {
            padding: 1rem;
            font-size: 0.9rem;
            color: #334155;
            border-bottom: 1px solid #f1f5f9;
            vertical-align: middle;
        }
        .custom-table tr:hover td {
            background-color: #f8fafc;
        }
        
        /* Green Assign Button */
        .btn-assign {
            background-color: #198754;
            color: #ffffff !important;
            border: none;
            padding: 0.5rem 1.25rem;
            border-radius: 6px;
            font-weight: 500;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: background-color 0.2s ease;
            box-shadow: 0 4px 10px rgba(25, 135, 84, 0.15);
            cursor: pointer;
        }
        .btn-assign:hover {
            background-color: #157347;
        }

        /* Custom Checkbox */
        .custom-checkbox-input {
            width: 18px;
            height: 18px;
            cursor: pointer;
            accent-color: #0d6efd;
            vertical-align: middle;
        }

        /* Pagination and Footer Styling */
        .custom-table-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 1.25rem 1.5rem;
            background: #ffffff;
            border-top: 1px solid #f1f5f9;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .custom-table-info {
            font-size: 0.85rem;
            color: #64748b;
        }
    </style>

    <div class="custom-card">
        <div class="custom-card-header">
            <h4><i class="pe-7s-note2"></i> Lead Details</h4>
            <div class="calendar-badge">
                <div class="calendar-badge-icon">
                    <i class="fa fa-calendar"></i>
                </div>
                <div class="calendar-badge-text">
                    <span class="calendar-badge-label">Posted On</span>
                    <span class="calendar-badge-value">{{ date('d-M-Y', strtotime($enquiry->created_at)) }}</span>
                </div>
            </div>
        </div>
        <div class="custom-card-body">
            <div class="info-grid">
                <!-- Left Column -->
                <div class="d-flex flex-column gap-2">
                    <div class="info-item">
                        <div class="info-icon-container">
                            <i class="fa fa-building"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">
                                @if($enquiry->property_id)
                                Property Name
                                @elseif($enquiry->project_id)
                                Project Name
                                @else
                                Property Name
                                @endif
                            </span>
                            <span class="info-colon">:</span>
                            <span class="info-value">{{ $enquiry->property_id ? $enquiry->property_name : ($enquiry->project_id ? $enquiry->project_name : '—') }}</span>
                        </div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-icon-container">
                            <i class="fa fa-user"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">Owner Name</span>
                            <span class="info-colon">:</span>
                            <span class="info-value">{{ $enquiry->owner ?? '—' }}</span>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon-container">
                            <i class="fa fa-user"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">Customer Name</span>
                            <span class="info-colon">:</span>
                            <span class="info-value">{{ $enquiry->customer }}</span>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon-container">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">Customer Phone</span>
                            <span class="info-colon">:</span>
                            <span class="info-value">{{ $enquiry->customer_phone }}</span>
                        </div>
                    </div>
                </div>

                <!-- Right Column -->
                <div class="d-flex flex-column gap-2">
                    <div class="info-item">
                        <div class="info-icon-container">
                            <i class="fa fa-envelope"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">Customer Email</span>
                            <span class="info-colon">:</span>
                            <span class="info-value">{{ $enquiry->customer_email }}</span>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon-container">
                            <i class="fa fa-calendar"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">Posted On</span>
                            <span class="info-colon">:</span>
                            <span class="info-value">{{ date('d-M-Y', strtotime($enquiry->created_at)) }}</span>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon-container">
                            <i class="fa fa-comment"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">Message</span>
                            <span class="info-colon">:</span>
                            <span class="info-value">{{ $enquiry->message ?? '—' }}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="custom-tabs-container">
        <ul class="custom-tabs">
            <li>
                <a class="custom-tab-link ajax-link {{ Request::is('enquiry/assign-list/'.$enquiry->enquery_id) ? 'active' : '' }}"
                    href="{{ url('enquiry/assign-list/'.$enquiry->enquery_id) }}" data-url="{{ url('enquiry/assign-list/'.$enquiry->enquery_id) }}">
                    Unassigned
                </a>
            </li>
            <li>
                <a class="custom-tab-link ajax-link {{ Request::is('enquiry/assign-list/assigned/'.$enquiry->enquery_id) ? 'active' : '' }}"
                    href="{{ url('enquiry/assign-list/assigned/'.$enquiry->enquery_id) }}" data-url="{{ url('enquiry/assign-list/assigned/'.$enquiry->enquery_id) }}">
                    Assigned
                </a>
            </li>
        </ul>
    </div>


    <div class="custom-card">
        <div class="custom-card-header">
            <h4><i class="pe-7s-users"></i> {{ $title }}</h4>
            @if($assign_type == 'unassigned')
            <div>
                <button type="button" class="btn-assign" onclick="assign()">
                    <i class="fa fa-user-plus"></i> Assign
                </button>
            </div>
            @endif
        </div>
        <div class="custom-card-body p-0">
            <div class="table-responsive" id="assign_table">
                <form id="assign-form">
                    <input type="hidden" name="enquery_id" value="{{ $enquiry->enquery_id }}" />
                    <table id="myTable" class="custom-table mb-0">
                        <thead>
                            <tr>
                                @if($assign_type == 'unassigned')
                                <th style="width:10%; text-align: center;">Check</th>
                                @endif
                                <th style="width:15%">User ID</th>
                                <th style="width:45%">Member Name</th>
                                <th style="width:30%">Leads (Used / Total)</th>
                                @if($assign_type == 'assigned')
                                <th style="width:25%">Assigned Date</th>
                                <th style="width:10%; text-align: center;">Action</th>
                                @endif
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($list as $item)
                            @php
                            $is_clickable = 0;
                            @endphp
                            @if($item->leads > $item->leads_used)
                            @php
                            $is_clickable = 1;
                            @endphp
                            @endif
                            <tr>
                                @if($assign_type == 'unassigned')
                                <td style="text-align: center;">
                                    <input name="userid[]" value="{{ $item->user_id }}" type="checkbox" class="custom-checkbox-input user-selected" {{ !$is_clickable ? 'disabled' : '' }} />
                                </td>
                                @endif
                                <td>{{ $item->user_id }}</td>
                                <td style="font-weight: 500;">{{ $item->member_name }}</td>
                                <td>{{ $item->leads ? $item->leads_used . '/' . ($item->leads == 'Unlimited' ? '∞' : $item->leads) : '0/0' }}</td>
                                @if($assign_type == 'assigned')
                                <td class="text-nowrap">{{ $item->created_at ? date('d-M-Y', strtotime($item->created_at)) : '' }}</td>
                                <td style="text-align: center;">
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Remove from assigned list" class="allUsersDeleteButton" style="cursor: pointer;" user-id="{{ $item->user_id }}" onclick="remove_assigned('{{ $item->assign_id }}')">
                                        <i class="fa fa-trash text-danger fa-lg"></i>
                                    </a>
                                </td>
                                @endif
                            </tr>
                            @empty
                            <tr>
                                <td colspan="{{ $assign_type == 'unassigned' ? 4 : 5 }}" class="text-center py-4 text-muted">
                                    <i class="fa fa-info-circle me-1"></i> Sorry, no records found!
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </form>
            </div>

            <div class="custom-table-footer">
                <div class="custom-table-info">
                    Showing {{ $list->firstItem() ?? 0 }} to {{ $list->lastItem() ?? 0 }} of {{ $list->total() ?? 0 }} entries
                </div>
                <div>
                    {!! $list->links('vendor.pagination.bootstrap-5') !!}
                </div>
            </div>

    </div>
</div>
</div>
@endsection
@section('modals')
<div class="modal fade" id="modal_action" tabindex="-1" role="dialog" aria-labelledby="addEditModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">

                <h5 class="modal-title" id="AddEditModalLabel"></h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal">

                </button>
            </div>
            <div class="modal-body">

                <form id="formData">
                    <input type="text" class='d-none' id="countryId" name="countryId">
                    @php
                    $langs = explode(',', admin_default_lang());
                    @endphp
                    @foreach($langs as $lang)
                    <div class="form-group">
                        <label for="name">{{ __('Name') }} ({{ strtoupper($lang) }})</label>
                        <input type="text" class="form-control reset_field" id="name_{{ $lang }}" name="name[{{ $lang }}]" autocomplete="off">
                        <div class="invalid-feedback" id="name_{{ $lang }}_error"></div>
                    </div>
                    @endforeach

                    <div class="form-group">
                        <label for="Order">Order</label>
                        <input type="Order" class="form-control" id="order" name="order" required>
                        <div class="invalid-feedback" id="Order_error"></div>
                    </div>


                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <div class="radio-inline">
                            <input type="radio" name="status" value=1 class="magic-radio" id="status_1" checked required>
                            <label for="status_1">Active</label>
                            <input type="radio" name="status" value=0 class="magic-radio" id="status_2">
                            <label for="status_2">Inactive</label>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" onclick="add_edit()" id="button" class="btn btn-primary">Save</button>
            </div>
        </div>

    </div>
</div>
@endsection
@push('custom-js')
<script>
    function assign() {
        var formId = $("#assign-form");
        var ln = $('#assign-form input[name="userid[]"]:checked').length;
        if (ln > 0) {
            $.ajax({
                type: 'POST',
                url: '{{ url("/enquiry/save-assign-list") }}',
                data: $(formId).serialize(),
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                dataType: 'JSON',
                success: function(res) {
                    if (res.status == 'OK') {
                        Swal.fire({
                            title: "Success!",
                            text: 'Lead assigned to member(s) successfully !',
                            icon: "success",
                            confirmButtonText: "OK"
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location = location.href;
                            }
                        });
                    } else {
                        Swal.fire({
                            title: "Failed!",
                            text: 'Failed to assign members',
                            icon: "error",
                            confirmButtonText: "OK"
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location = res.redirect;
                            }
                        });
                    }
                }
            });
        } else {
            Swal.fire({
                title: "Warning!",
                text: 'Please select member(s)',
                icon: "warning",
                confirmButtonText: "OK"
            });
        }
    }

    function remove_assigned(assign_id) {
        if (assign_id) {
            Swal.fire({
                title: 'Are you sure?',
                text: "Are you sure want to remove from assigned list?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, remove it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: 'POST',
                        url: '{{ url("/enquiry/remove-assign-list") }}',
                        data: {
                            assign_id: assign_id
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        dataType: 'JSON',
                        success: function(res) {
                            if (res.status == 'OK') {
                                Swal.fire({
                                    title: "Success!",
                                    text: 'Member removed from assigned list.',
                                    icon: "success",
                                    confirmButtonText: "OK"
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        window.location = location.href;
                                    }
                                });
                            }
                        }
                    });
                }
            });
        }
    }

    function Edit(id) {
        $('.form-control').removeClass('is-invalid');
        $('.invalid-feedback').empty();
        AddEdit('Edit', 'Update', id);
    }

    function AddEdit(title, buttonText, id = null) {
        $('#AddEditModalLabel').text(title);
        $('#button').text(buttonText);
        $('#formData')[0].reset();
        if (id) {
            $.get(`{{ url('/country/details') }}/${id}`, function(data) {
                $('#countryId').val(data[0].country_id);
                data.forEach(function(country) {
                    $('#name_' + country.lang).val(country.name);
                    if (country.lang === 'en') {
                        $('#order').val(country.order);
                        $('input[name="status"][value="' + country.status + '"]').prop(
                            'checked', true);
                    }
                });
            });
        }
        $('#modal_action').modal('show');
    }

    function add_edit() {
        var data = $("#formData").serializeArray();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var url = $('#countryId').val() ?
            `{{ url('/edit/country') }}` :
            `{{ url('/add/country') }}`;

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            success: function(response) {
                localStorage.setItem('successMessage', response.message);
                window.location.reload(true);
                $('#modal_action').modal('hide');
                $('#formData')[0].reset();
            },
            error: function(response) {
                var errors = response.responseJSON.errors;

                // Reset previous error messages and invalid class
                $('.invalid-feedback').text('').hide();
                $('.form-control').removeClass('is-invalid');

                // Loop through errors and update the DOM
                Object.entries(errors).forEach(([field, messages]) => {
                    const fieldId = field.replace('.', '_'); // Convert 'name.en' to 'name_en'
                    const inputSelector = `#${fieldId}`;
                    const errorSelector = `#${fieldId}_error`;

                    $(inputSelector).addClass('is-invalid');
                    $(errorSelector).text(messages[0]).show();
                });

            }

        });
    }



    $('.status').change(function() {

        toastr.success('Request processed successfully.', 'Request Status', toastrOptions);

        var id = $(this).data('id');
        var status = this.checked ? 1 : 0;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: 'POST',
            url: `{{ url('/country/status') }}`,
            data: {
                'status': status,
                'id': id
            },
            success: function(data) {
                // Handle success response if needed
            },
            error: function(msg) {
                console.log(msg);
                var errors = msg.responseJSON;
            }
        });
    });

    function Delete(id) {
        var result = confirm('Are you sure you want to delete this?');
        console.log(id);
        if (result) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: 'POST',
                url: `{{ url('/country/delete') }}`,
                data: {
                    'id': id
                },
                success: function(response) {
                    localStorage.setItem('successMessage', response.message);
                    window.location.reload(true);
                },
                error: function(msg) {
                    console.log(msg);
                    var errors = msg.responseJSON;
                }
            });
        }
    }

    $(document).ready(function() {
        var table = $('#myTable').DataTable({
            "paging": false,
            "searching": false,
            "info": false,
            "ordering": true,
            "order": [
                [0, 'desc']
            ],
            "columnDefs": [{
                    "orderable": true,
                    "targets": [0]
                },
                {
                    "orderable": false,
                    "targets": [2, 3, 4]
                }
            ]
        });
    });
</script>


@endpush