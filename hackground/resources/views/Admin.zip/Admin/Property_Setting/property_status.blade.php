@extends('Admin.layouts.app')

@section('content')

<div class="body-page-loader d-none">
    <div class="loader">
        <div class="line-scale-pulse-out">
            <div class="bg-warning"></div>
            <div class="bg-warning"></div>
            <div class="bg-warning"></div>
            <div class="bg-warning"></div>
            <div class="bg-warning"></div>
        </div>
    </div>
</div>

<div class="app-main__inner">

    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-notebook icon-gradient bg-mixed-hopes"></i>
                </div>
                <div>Property Status
                    <div class="page-title-subheading">Property Setting &gt; Property Status List</div>
                </div>
            </div>
            <div class="page-title-actions">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}"> Home</a></li>
                    <li class="breadcrumb-item active">Property Status List</li>
                </ol>
            </div>
        </div>
    </div>
    <div id="successMessageContainer"></div>
    <style>
        .advance-search-panel {
            background-color: #fff;
            box-shadow: 0 1px 3px rgb(0 0 0 / 10%);
            padding: 1rem;
            margin-top: 1rem;
        }
    </style>
    @if (session('success_msg'))
    <div class="alert alert-{{ session('message_type') }}">
        {{ session('success_msg') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert">

        </button>
    </div>
    @endif

    <form action="{{ url('property/status') }}" method="get">
        <section class="content-header mb-2">
            <div class="row justify-content-end">
                <div class="col-xl-4 col-lg-6">
                    <div class="input-group">
                        <input class="form-control" id="prop_status_search" placeholder="Search..." name="term"
                            value="{{ request('term') }}" />
                        <div class="input-group-append">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-search"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </form>

    <div class="main-card mb-3 card">
        <div class="card-header d-flex">
        <h4>Property Status List</h4>

                <div class="btn-actions-pane-right">
                    <button type="button" class="btn btn-sm btn-primary" onclick="add_prop_status()">Add
                        Status</button>
                </div>

            </div>
        <div class="card-body">


            <div class="table-responsive" id="main_table">
                <table id="status" class="mb-0 table">
                    <thead>
                    <tr>
                            <th style="width:32px">ID</th>
                            <th style="min-width:120px">Name</th>
                            <th>Order</th>

                            <th>Icon</th>
                            <th>Status</th>
                            <th style="min-width:60px;" class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody id="user">
                        @if (!empty($data))
                        @foreach ($data as $item)

                        <tr>
                            <td>{{ $item->id }}</td>
                            <td>{{ $item->name }}</td>
                            <td>{{ $item->order }}</td>
                            <td>
                                <img src="{{ asset('user_upload/status/' . $item->icon) }}" alt="N/A"
                                class="img-fluid" height="36" width="36">
                            </td>
                            <td>
                                <input data-id="{{ $item->id }}" class="status_prop_status d-none"
                                    type="checkbox" data-toggle="toggle" data-on="Active" data-off="Inactive"
                                    data-onstyle="success" data-offstyle="danger" data-size="mini"
                                    {{ $item->status ? 'checked' : '' }}>
                            </td>
                            <td class="text-right">
                                <a href="javascript:void(0)" onclick="Edit_prop_status('{{ $item->id }}')" class="me-2"><i class="bi bi-pencil-square text-success fa-md "></i></a>
                                <a href="javascript:void(0)" onclick="Delete_prop_status('{{ $item->id }}')"><i class="bi bi-trash3-fill text-danger fa-md"></i></a>
                            </td>
                        </tr>


                        @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
            {!! $data->links('vendor.pagination.bootstrap-5') !!}
        </div>
    </div>
</div>
@endsection
@section('modals')
<div class="modal fade" id="prop_status" tabindex="-1" role="dialog"
    aria-labelledby="prop_statusaddEditModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">

                <h5 class="modal-title" id="prop_statusAddEditModalLabel"></h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal">

                </button>
            </div>
            <div class="modal-body">

                <form id="prop_statusformData">
                    <input type="hidden" class='d-none' id="filename" name="icon">
                    <input type="text" class='d-none' id="prop_statusId" name="prop_statusId">
                    @php
                    $langs = explode(',', admin_default_lang());
                    @endphp
                    @foreach ($langs as $lang)
                    <div class="form-floating mb-3">

                        <input type="text" class="form-control reset_field" id="name_{{ $lang }}"
                            name="name[{{ $lang }}]" autocomplete="off">
                            <label for="name">{{ __('Name') }} ({{ strtoupper($lang) }})</label>
                        <div class="invalid-feedback" id="name_{{ $lang }}_error"></div>
                    </div>
                    @endforeach

                    <div class="form-group">
                        <!-- <label for="ufile">Icon</label> -->
                        <input type="file" name="file" id="fileUpload" class="form-control" onchange="updateFileName()">
                    </div>

                    <div class="form-group">
                        <img id="image_preview" src=" " style="display:none; width: 64px; height: 64px;" />
                        <button type="button" id="delete_image_btn" style="display:none;"
                        class="btn btn-danger btn-sm" title="Delete Image" onclick="deleteUploadedImage()"><i class="bi bi-trash3-fill"></i></button>
                    </div>

                    <div class="form-floating mb-3">

                        <input type="Order" class="form-control" id="order" name="order" placeholder="" required>
                        <label for="Order">Order</label>
                        <div class="invalid-feedback" id="Order_error"></div>
                    </div>


                    <div class="form-group mb-0">
                        <label class="form-label d-block">Status</label>
                        <div class="form-check form-check-inline">
                            <input type="radio" name="status" value=1 class="form-check-input" id="status_1" checked
                                required>
                            <label class="form-check-label" for="status_1">Active</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input type="radio" name="status" value=0 class="form-check-input" id="status_2">
                            <label class="form-check-label" for="status_2">Inactive</label>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="add_edit_prop_status()" id="prop_statusButton"
                    class="btn btn-primary">Save</button>
            </div>
        </div>

    </div>
</div>
@endsection
@push('custom-js')
<script>
    function add_prop_status() {
        $('.form-control').removeClass('is-invalid');
        $('.invalid-feedback').empty();
        prop_statusAddEdit('Property Status Add', 'Add');
    }

    function Edit_prop_status(id) {
        console.log(id);
        $('.form-control').removeClass('is-invalid');
        $('.invalid-feedback').empty();
        prop_statusAddEdit('Property Status Edit', 'Update', id);
    }

    function prop_statusAddEdit(title, buttonText, id = null) {
        $('#prop_statusAddEditModalLabel').text(title);
        $('#prop_statusButton').text(buttonText);
        $('#prop_statusformData')[0].reset();
        if (id) {
            $.get(`{{ url('/property/status-details') }}/${id}`, function(data) {

                $('#prop_statusId').val(data[0].status_id);
                data.forEach(function(status) {
                    $('#name_' + status.lang).val(status.name);
                    if (status.lang === 'en') {

                        var imageSrc = `{{ asset('user_upload/status') }}/${status.icon}`;
                        if (status.icon) {
                            $('#image_preview').attr('src', imageSrc).show();
                            $('#delete_image_btn').show();
                        }
                        $('#filename').val(status.icon);
                        $('#order').val(status.order);
                        $('input[name="status"][value="' + status.status + '"]').prop(
                            'checked', true);
                    }
                });
            });
        }
        $('#prop_status').modal('show');
    }

    function add_edit_prop_status() {
        var data = $("#prop_statusformData").serializeArray();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var url = $('#prop_statusId').val() ?
            `{{ url('/property/edit-property-status') }}` :
            `{{ url('/property/add-property-status') }}`;

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            success: function(response) {
                // localStorage.setItem('successMessage', response.message);
                window.location.reload(true);
                $('#prop_status').modal('hide');
                $('#prop_statusformData')[0].reset();
            },
            error: function(response) {
                var errors = response.responseJSON.errors;

                // Reset previous error messages and invalid class
                $('.invalid-feedback').text('').hide();
                $('.form-control').removeClass('is-invalid');

                // Loop through errors and update the DOM
                Object.entries(errors).forEach(([field, messages]) => {
                    const fieldId = field.replace('.', '_'); // Convert 'name.en' to 'name_en'
                    const inputSelector = `#${fieldId}`;
                    const errorSelector = `#${fieldId}_error`;

                    $(inputSelector).addClass('is-invalid');
                    $(errorSelector).text(messages[0]).show();
                });

            }

        });
    }

    $('#fileUpload').change(function(event) {
        var fileInput = event.target;
        var file = fileInput.files[0];
        var fileLabel = document.querySelector('.custom-file-label');
        fileLabel.textContent = file.name;

        var reader = new FileReader();
        reader.onload = function(e) {
            var imagePreview = document.getElementById('image_preview');
            imagePreview.style.display = 'block';
            imagePreview.src = e.target.result;
        };

        if (file) {
            reader.readAsDataURL(file);
        }

        var formData = new FormData();
        formData.append('file', file);
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: `{{ url('property/status/upload') }}`,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                console.log('File uploaded successfully');
                // Optionally store the file name or URL if necessary (e.g., in a hidden input field)
                $('#filename').val(response.fileName); // Set file name in hidden field
                $('#image_preview').attr('src', response.filePath).show();
                $('#delete_image_btn').show();
            },
            error: function(xhr, status, error) {
                console.error('Error uploading file:', error);
            }
        });
    });

    function deleteUploadedImage() {
        var fileName = $('#filename').val();
        alert(fileName);
        if (!fileName) {
            alert('No image to delete!');
            return;
        }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            url: `{{ url('property/status/image-delete') }}`,
            type: 'POST',
            data: {
                file: fileName
            },
            success: function(response) {
                console.log('File deleted successfully');
                $('#image_preview').attr('src', '').hide();
                $('#delete_image_btn').hide();
                $('#filename').val('');
            },
            error: function(xhr, status, error) {
                console.error('Error deleting file:', error);
            }
        });
    }


    $('.status_prop_status').change(function() {

        toastr.success('Request processed successfully.', 'Request Status', toastrOptions);

        var id = $(this).data('id');
        var status = this.checked ? 1 : 0;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: 'POST',
            url: `{{ url('property/status_status') }}`,
            data: {
                'status': status,
                'id': id
            },
            success: function(data) {
                // Handle success response if needed
            },
            error: function(msg) {
                console.log(msg);
                var errors = msg.responseJSON;
            }
        });
    });

    function Delete_prop_status(id) {
        var result = confirm('Are you sure you want to delete this?');
        console.log(id);
        if (result) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: 'POST',
                url: `{{ url('property/status-delete') }}`,
                data: {
                    'id': id
                },
                success: function(response) {
                    // localStorage.setItem('successMessage', response.message);
                    window.location.reload(true);
                },
                error: function(msg) {
                    console.log(msg);
                    var errors = msg.responseJSON;
                }
            });
        }
    }
    $(document).ready(function() {
        var table = $('#status').DataTable({
            "paging": false,
            "searching": false,
            "info": false,
            "ordering": true,
            "order": [
                [0, 'desc']
            ],
            "columnDefs": [{
                    "orderable": true,
                    "targets": [0]
                },
                {
                    "orderable": false,
                    "targets": [2, 3, 4]
                }
            ]
        });
    });
</script>
@endpush