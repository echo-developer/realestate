@extends('Admin.layouts.app')

@section('content')
<div class="body-page-loader d-none">
    <div class="loader">
        <div class="line-scale-pulse-out">
            <div class="bg-warning"></div>
            <div class="bg-warning"></div>
            <div class="bg-warning"></div>
            <div class="bg-warning"></div>
            <div class="bg-warning"></div>
        </div>
    </div>
</div>

<div class="app-main__inner">

    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-notebook icon-gradient bg-mixed-hopes"></i>
                </div>
                <div>Property Recommended
                    <div class="page-title-subheading">Property Setting &gt; Property Recommended List</div>
                </div>
            </div>
            <div class="page-title-actions">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}"> Home</a></li>
                    <li class="breadcrumb-item active">Property Recommended List</li>
                </ol>
            </div>
        </div>
    </div>
    <div id="successMessageContainer"></div>
    <style>
        .advance-search-panel {
            background-color: #fff;
            box-shadow: 0 1px 3px rgb(0 0 0 / 10%);
            padding: 1rem;
            margin-top: 1rem;
        }
    </style>
    @if (session('success_msg'))
    <div class="alert alert-{{ session('message_type') }}">
        {{ session('success_msg') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert">

        </button>
    </div>
    @endif

    <form action="{{ url('property/recommended') }}" method="get">
        <section class="content-header mb-2">
            <div class="row justify-content-end">
                <div class="col-xl-4 col-lg-6">
                    <div class="input-group">
                        <input class="form-control" id="prop_recommended_search" placeholder="Search..." name="term"
                            value="{{ request('term') }}" />
                        <div class="input-group-append">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-search"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </form>

    <div class="main-card mb-3 card">
        <div class="card-header d-flex">
        <h4>Property Recommended List</h4>
            <div class="btn-actions-pane-right">
                <button type="button" class="btn btn-sm btn-primary" onclick="add_prop_recommended()">Add Recommended</button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive" id="main_table">
                <table class="mb-0 table">
                    <thead>
                        <tr>
                            <th style="width:32px">ID</th>
                            <th>Name</th>
                            <th>Order</th>
                            <th>Status</th>
                            <th style="min-width:60px;" class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody id="user">
                        @if (!empty($data))
                        @foreach ($data as $item)

                        <tr>
                            <td>{{ $item->id }}</td>
                            <td>{{ $item->name }}</td>
                            <td>{{ $item->order }}</td>

                            <td>
                                <input data-id="{{ $item->id }}" class="recommended_prop_status d-none"
                                    type="checkbox" data-toggle="toggle" data-on="Active" data-off="Inactive"
                                    data-onstyle="success" data-offstyle="danger" data-size="mini"
                                    {{ $item->status ? 'checked' : '' }}>
                            </td>
                            <td class="text-right">
                                <a href="javascript:void(0)" onclick="Edit_prop_recommended('{{ $item->id }}')" class="me-2"><i class="bi bi-pencil-square text-success fa-md "></i></a>
                                <a href="javascript:void(0)" onclick="Delete_prop_recommended('{{ $item->id }}')"><i class="bi bi-trash3-fill text-danger fa-md"></i></a>
                            </td>
                        </tr>


                        @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
            {!! $data->links('vendor.pagination.bootstrap-5') !!}
        </div>
    </div>
</div>
@endsection
@section('modals')
<div class="modal fade" id="prop_recommended" tabindex="-1" role="dialog"
    aria-labelledby="prop_recommendedaddEditModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">

                <h5 class="modal-title" id="prop_recommendedAddEditModalLabel"></h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal">

                </button>
            </div>
            <div class="modal-body">

                <form id="prop_recommendedformData">
                    <input type="text" class='d-none' id="prop_recommendedId" name="prop_recommendedId">
                    @php
                    $langs = explode(',', admin_default_lang());
                    @endphp
                    @foreach ($langs as $lang)
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control reset_field" id="name_{{ $lang }}"
                            name="name[{{ $lang }}]" placeholder="" autocomplete="off">
                        <label for="name">{{ __('Name') }} ({{ strtoupper($lang) }})</label>
                        <div class="invalid-feedback" id="name_{{ $lang }}_error"></div>
                    </div>
                    @endforeach

                    <div class="form-floating mb-3">

                        <input type="Order" class="form-control" id="order" name="order" placeholder="" required>
                        <label for="Order">Order</label>
                        <div class="invalid-feedback" id="Order_error"></div>
                    </div>


                    <div class="form-group mb-0">
                        <label class="form-label d-block">Status</label>
                        <div class="form-check form-check-inline">
                            <input type="radio" name="status" value=1 class="form-check-input" id="status_1" checked
                                required>
                            <label class="form-check-label" for="status_1">Active</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input type="radio" name="status" value=0 class="form-check-input" id="status_2">
                            <label class="form-check-label" for="status_2">Inactive</label>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="add_edit_prop_recommended()" id="prop_recommendedButton"
                    class="btn btn-primary">Save</button>
            </div>
        </div>

    </div>
</div>
@endsection
@push('custom-js')
<script>
    function add_prop_recommended() {
        $('.form-control').removeClass('is-invalid');
        $('.invalid-feedback').empty();
        prop_recommendedAddEdit('Property Recommended Add', 'Add');
    }

    function Edit_prop_recommended(id) {
        console.log(id);
        $('.form-control').removeClass('is-invalid');
        $('.invalid-feedback').empty();
        prop_recommendedAddEdit('Property Recommended Edit', 'Update', id);
    }

    function prop_recommendedAddEdit(title, buttonText, id = null) {
        $('#prop_recommendedAddEditModalLabel').text(title);
        $('#prop_recommendedButton').text(buttonText);
        $('#prop_recommendedformData')[0].reset();
        if (id) {
            $.get(`{{ url('/property/recommended-details') }}/${id}`, function(data) {
                $('#prop_recommendedId').val(data[0].recommended_id);
                data.forEach(function(recommended) {
                    $('#name_' + recommended.lang).val(recommended.name);
                    if (recommended.lang === 'en') {
                        $('#order').val(recommended.order);
                        $('input[name="status"][value="' + recommended.status + '"]').prop(
                            'checked', true);
                    }
                });
            });
        }
        $('#prop_recommended').modal('show');
    }

    function add_edit_prop_recommended() {
        var data = $("#prop_recommendedformData").serializeArray();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var url = $('#prop_recommendedId').val() ?
            `{{ url('/property/edit-property-recommended') }}` :
            `{{ url('/property/add-property-recommended') }}`;

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            success: function(response) {
                // localStorage.setItem('successMessage', response.message);
                window.location.reload(true);
                $('#prop_recommended').modal('hide');
                $('#prop_recommendedformData')[0].reset();
            },
            error: function(response) {
                var errors = response.responseJSON.errors;

                // Reset previous error messages and invalid class
                $('.invalid-feedback').text('').hide();
                $('.form-control').removeClass('is-invalid');

                // Loop through errors and update the DOM
                Object.entries(errors).forEach(([field, messages]) => {
                    const fieldId = field.replace('.', '_'); // Convert 'name.en' to 'name_en'
                    const inputSelector = `#${fieldId}`;
                    const errorSelector = `#${fieldId}_error`;

                    $(inputSelector).addClass('is-invalid');
                    $(errorSelector).text(messages[0]).show();
                });

            }

        });
    }



    $('.recommended_prop_status').change(function() {

        toastr.success('Request processed successfully.', 'Request Status', toastrOptions);

        var id = $(this).data('id');
        var status = this.checked ? 1 : 0;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: 'POST',
            url: `{{ url('property/recommended_status') }}`,
            data: {
                'status': status,
                'id': id
            },
            success: function(data) {
                // Handle success response if needed
            },
            error: function(msg) {
                console.log(msg);
                var errors = msg.responseJSON;
            }
        });
    });

    function Delete_prop_recommended(id) {
        var result = confirm('Are you sure you want to delete this?');
        console.log(id);
        if (result) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: 'POST',
                url: `{{ url('property/recommended-delete') }}`,
                data: {
                    'id': id
                },
                success: function(response) {
                    // localStorage.setItem('successMessage', response.message);
                    window.location.reload(true);
                },
                error: function(msg) {
                    console.log(msg);
                    var errors = msg.responseJSON;
                }
            });
        }
    }
    $(document).ready(function() {
        var table = $('.table').DataTable({
            "paging": false,
            "searching": false,
            "info": false,
            "ordering": true,
            "order": [
                [0, 'desc']
            ],
            "columnDefs": [{
                    "orderable": true,
                    "targets": [0]
                },
                {
                    "orderable": false,
                    "targets": [2, 3, 4]
                }
            ]
        });
    });
</script>
@endpush